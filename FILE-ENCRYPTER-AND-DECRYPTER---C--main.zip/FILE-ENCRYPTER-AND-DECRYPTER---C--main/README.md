# FILE-ENCRYPTER-AND-DECRYPTER---C-
This project is a Parallel File Encryptor built using C++ that leverages multithreading to efficiently encrypt and decrypt large files. By utilizing parallel processing, the program significantly improves performance over traditional single-threaded encryption methods.
